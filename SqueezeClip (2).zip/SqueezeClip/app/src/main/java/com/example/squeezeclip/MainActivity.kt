package com.example.squeezeclip

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

// ---- Palette (from the SqueezeClip design) ----
private val Bg = Color(0xFF0A151A)
private val CardC = Color(0xFF172127)
private val CardHigh = Color(0xFF212B32)
private val CardHighest = Color(0xFF2C363D)
private val Primary = Color(0xFF59DCB5)
private val PrimaryC = Color(0xFF00A884)
private val OnPrimaryC = Color(0xFF003427)
private val OnSurf = Color(0xFFD9E4EC)
private val OnSurfVar = Color(0xFFBCCAC2)
private val Err = Color(0xFFFFB4AB)

private val SqueezeColors = darkColorScheme(
    primary = Primary,
    onPrimary = Color(0xFF00382A),
    primaryContainer = PrimaryC,
    onPrimaryContainer = OnPrimaryC,
    background = Bg,
    onBackground = OnSurf,
    surface = Bg,
    onSurface = OnSurf,
    surfaceVariant = CardHighest,
    onSurfaceVariant = OnSurfVar,
    error = Err
)

private class Actions(
    val share: (List<File>, Boolean) -> Unit,
    val save: (List<File>) -> Unit,
    val play: (Uri) -> Unit,
    val playFile: (File) -> Unit
)

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val actions = Actions(
            share = { files, wa -> share(files, wa) },
            save = { files -> saveToGallery(files) },
            play = { uri -> play(uri) },
            playFile = { f -> play(FileProvider.getUriForFile(this, "$packageName.fileprovider", f)) }
        )
        setContent {
            MaterialTheme(colorScheme = SqueezeColors) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    App(vm, actions)
                }
            }
        }
    }

    private fun play(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "video/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No video player found.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun share(files: List<File>, whatsAppOnly: Boolean) {
        val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = "video/mp4"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            if (whatsAppOnly) {
                intent.setPackage("com.whatsapp")
                startActivity(intent)
            } else {
                startActivity(Intent.createChooser(intent, "Share"))
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "That app isn't installed.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveToGallery(files: List<File>) {
        var saved = 0
        for (f in files) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "SqueezeClip_${System.currentTimeMillis()}_${f.name}")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SqueezeClip")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: continue
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            saved++
        }
        Toast.makeText(this, "Saved $saved file(s) to Movies/SqueezeClip", Toast.LENGTH_LONG).show()
    }
}

private fun fmtTime(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
private fun fmtSize(bytes: Long) = if (bytes <= 0) "unknown size" else "%.1f MB".format(bytes / 1048576.0)

// ---------------------------------------------------------------- shared pieces

@Composable
private fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(CardC)
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun Pill(text: String, color: Color = Primary, bg: Color = CardHighest) {
    Text(
        text,
        color = color,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun Label(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = OnSurfVar,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = modifier
    )
}

@Composable
private fun BigButton(text: String, onClick: () -> Unit, enabled: Boolean = true, primary: Boolean = true) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(58.dp),
        enabled = enabled,
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) PrimaryC else CardHigh,
            contentColor = if (primary) OnPrimaryC else OnSurf,
            disabledContainerColor = CardHigh,
            disabledContentColor = OnSurfVar
        )
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TopBar(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = OnSurf)
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = OnSurf, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = OnSurfVar, fontSize = 12.sp)
        }
        trailing?.invoke()
    }
}

@Composable
private fun Thumb(bmp: ImageBitmap?, modifier: Modifier, onPlay: (() -> Unit)?, badge: String? = null) {
    Box(
        modifier.clip(RoundedCornerShape(18.dp)).background(CardHighest),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        if (onPlay != null) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(PrimaryC.copy(alpha = 0.9f))
                    .clickable(onClick = onPlay),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, "Play", tint = OnPrimaryC)
            }
        }
        if (badge != null) {
            Text(
                badge,
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x99000000))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
    }
}

// ---------------------------------------------------------------- root

@Composable
private fun App(vm: MainViewModel, a: Actions) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.load(uri)
    }
    val choose = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        when {
            vm.working -> CompressingScreen(vm)
            vm.done && vm.results.isNotEmpty() -> CompleteScreen(vm, a) {
                vm.closeVideo()
                choose()
            }
            vm.info != null -> ConfigureScreen(vm, a, choose)
            else -> HomeScreen(vm, choose)
        }
    }
}

// ---------------------------------------------------------------- home

@Composable
private fun HomeScreen(vm: MainViewModel, onChoose: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(CardHigh).padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, null, tint = Primary, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text("100% ON-DEVICE PRIVACY", color = Primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
        }
        Text("SqueezeClip", color = OnSurf, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text(
            "Shrink and split videos before you post them. Everything runs on your phone.",
            color = OnSurfVar,
            fontSize = 16.sp
        )
        BigButton("Choose a video", onChoose)
        if (vm.status.isNotEmpty()) Text(vm.status, color = Err)

        Label("RECOMMENDED PRESETS")
        PresetRow("\uD83D\uDCAC", "WhatsApp Status", "Balanced quality, split into 30-second parts", "30s parts") {
            vm.applyQuick(MainViewModel.Preset.BALANCED, true)
            onChoose()
        }
        PresetRow("\u26A1", "Chat Direct Send", "Small file, no splitting, quick to send", "Fast") {
            vm.applyQuick(MainViewModel.Preset.SMALL, false)
            onChoose()
        }
        PresetRow("\uD83C\uDF9A", "Custom Compress", "Pick the quality and trim it yourself", "Manual") {
            vm.applyQuick(MainViewModel.Preset.SHARP, false)
            onChoose()
        }

        Label("WHY SQUEEZECLIP")
        InfoRow("\uD83D\uDD0D", "Smaller files, still sharp", "Three quality levels. Videos are scaled down only when needed, never upscaled.")
        InfoRow("\u2702\uFE0F", "Auto 30s splitting", "Long videos are cut into 30-second parts, ready for WhatsApp Status.")
        InfoRow("\uD83D\uDD12", "Stays on your phone", "Compression runs locally. No uploads, no account, no internet needed.")
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun PresetRow(emoji: String, title: String, sub: String, tag: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(CardC)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(CardHigh), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 22.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = OnSurf, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = OnSurfVar, fontSize = 13.sp)
        }
        Pill(tag)
    }
}

@Composable
private fun InfoRow(emoji: String, title: String, text: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardC).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(CardHigh), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 20.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = OnSurf, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(text, color = OnSurfVar, fontSize = 13.sp)
        }
    }
}

// ---------------------------------------------------------------- configure

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConfigureScreen(vm: MainViewModel, a: Actions, onChoose: () -> Unit) {
    val info = vm.info ?: return
    BackHandler { vm.closeVideo() }
    val ranges = vm.previewRanges()
    val est = vm.estimatedBytes()

    Column(Modifier.fillMaxSize()) {
        TopBar("Configure", "On-device compression", onBack = { vm.closeVideo() })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Primary))
                    Spacer(Modifier.width(8.dp))
                    Label("SOURCE LOADED")
                }
                TextButton(onClick = onChoose) { Text("Choose a different video", color = Primary, fontSize = 13.sp) }
            }

            Panel {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Thumb(vm.thumb, Modifier.size(width = 110.dp, height = 150.dp), { a.play(info.uri) }, fmtTime(info.durationMs))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("${info.width}x${info.height}")
                        Text(info.name, color = OnSurf, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${fmtTime(info.durationMs)} long \u2022 ${fmtSize(info.sizeBytes)}", color = OnSurfVar, fontSize = 14.sp)
                    }
                }
            }

            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Trim video", color = OnSurf, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Pill("${fmtTime(vm.trimStart.toLong())} - ${fmtTime(vm.trimEnd.toLong())}")
                }
                RangeSlider(
                    value = vm.trimStart..vm.trimEnd,
                    onValueChange = { vm.trimStart = it.start; vm.trimEnd = it.endInclusive },
                    valueRange = 0f..info.durationMs.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Primary,
                        activeTrackColor = Primary,
                        inactiveTrackColor = CardHighest
                    )
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("0:00", color = OnSurfVar, fontSize = 12.sp)
                    Text("Selected: %.1f s".format((vm.trimEnd - vm.trimStart) / 1000f), color = Primary, fontSize = 12.sp)
                    Text(fmtTime(info.durationMs), color = OnSurfVar, fontSize = 12.sp)
                }
            }

            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Quality", color = OnSurf, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    if (est > 0) Pill("~${fmtSize(est)}")
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MainViewModel.Preset.values().forEach { p ->
                        QualityBox(p, vm.preset == p, Modifier.weight(1f)) { vm.preset = p }
                    }
                }
            }

            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Split into 30-second parts", color = OnSurf, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Good for WhatsApp Status clips", color = OnSurfVar, fontSize = 13.sp)
                    }
                    Switch(
                        checked = vm.split,
                        onCheckedChange = { vm.split = it },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = PrimaryC,
                            checkedThumbColor = Color.White
                        )
                    )
                }
                if (ranges.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Pill("This will make ${ranges.size} file(s)")
                }
            }

            if (vm.status.isNotEmpty()) Text(vm.status, color = Err)
            Spacer(Modifier.height(4.dp))
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            BigButton("Compress", vm::start, enabled = ranges.isNotEmpty())
        }
    }
}

@Composable
private fun QualityBox(p: MainViewModel.Preset, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) PrimaryC.copy(alpha = 0.25f) else CardHigh)
            .then(if (selected) Modifier.border(2.dp, Primary, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(p.label, color = OnSurf, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(p.sub, color = if (selected) Primary else OnSurfVar, fontSize = 12.sp)
    }
}

// ---------------------------------------------------------------- compressing

@Composable
private fun CompressingScreen(vm: MainViewModel) {
    BackHandler { vm.cancel() }
    val p = vm.progress
    val info = vm.info

    Column(Modifier.fillMaxSize()) {
        TopBar(
            "Optimizing video...",
            "Keep SqueezeClip open",
            trailing = {
                IconButton(onClick = vm::cancel) { Icon(Icons.Default.Close, "Cancel", tint = OnSurf) }
            }
        )
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(28.dp)).background(CardHighest),
                contentAlignment = Alignment.Center
            ) {
                val bmp = vm.thumb
                if (bmp != null) {
                    Image(bmp, null, Modifier.fillMaxSize().alpha(0.3f), contentScale = ContentScale.Crop)
                }
                CircularProgressIndicator(progress = 1f, modifier = Modifier.size(170.dp), color = Color(0x33FFFFFF), strokeWidth = 10.dp)
                CircularProgressIndicator(progress = p, modifier = Modifier.size(170.dp), color = Primary, strokeWidth = 10.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${(p * 100).toInt()}%", color = OnSurf, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                    Label("SQUEEZING")
                }
            }

            Panel {
                Text("Real-time savings", color = OnSurf, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Label("ORIGINAL")
                        Text(fmtSize(info?.sizeBytes ?: 0L), color = OnSurf, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Label("ESTIMATED OUTPUT")
                        Text("~" + fmtSize(vm.estimatedBytes()), color = Primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    val rem = vm.remainingSec
                    Text(if (rem != null) "About ${rem}s left" else "Estimating time...", color = OnSurfVar, fontSize = 13.sp)
                    Text("H.264 \u2022 AAC", color = OnSurfVar, fontSize = 13.sp)
                }
            }

            Panel {
                Label("PROGRESS")
                Spacer(Modifier.height(10.dp))
                for (n in 0 until vm.partCount) {
                    val frac = (p * vm.partCount - n).coerceIn(0f, 1f)
                    val state = when {
                        n < vm.partIndex -> "Done"
                        n == vm.partIndex -> "${(frac * 100).toInt()}%"
                        else -> "Pending"
                    }
                    val name = if (vm.partCount == 1) "Compressing video" else "Part ${n + 1} of ${vm.partCount}"
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(name, color = if (n > vm.partIndex) OnSurfVar else OnSurf, fontSize = 15.sp)
                        Text(state, color = if (n > vm.partIndex) OnSurfVar else Primary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Panel {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.Lock, null, tint = Primary)
                    Column {
                        Text("100% private, on-device", color = OnSurf, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Compression runs on your phone and uses no mobile data.", color = OnSurfVar, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            BigButton("Cancel processing", vm::cancel, primary = false)
        }
    }
}

// ---------------------------------------------------------------- complete

@Composable
private fun CompleteScreen(vm: MainViewModel, a: Actions, onAnother: () -> Unit) {
    BackHandler { vm.backToEdit() }
    val files = vm.results.toList()
    val total = files.sumOf { it.length() }
    val origSize = vm.info?.sizeBytes ?: 0L
    val saved = if (origSize > 0 && total > 0 && total < origSize) (100 - total * 100 / origSize).toInt() else 0

    Column(Modifier.fillMaxSize()) {
        TopBar("Done", "SqueezeClip", onBack = { vm.backToEdit() })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).size(84.dp).clip(CircleShape).background(PrimaryC),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, null, tint = OnPrimaryC, modifier = Modifier.size(44.dp))
            }
            Text(
                "Ready to post! \uD83C\uDF89",
                color = OnSurf, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Your clip is compressed and ready to share.",
                color = OnSurfVar, fontSize = 15.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )

            Panel {
                Thumb(
                    vm.resultThumb,
                    Modifier.fillMaxWidth().height(220.dp),
                    { files.firstOrNull()?.let { a.playFile(it) } },
                    "${files.size} file(s)"
                )
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Label("ORIGINAL")
                        Text(fmtSize(origSize), color = OnSurf, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Label("SQUEEZED")
                            if (saved > 0) Pill("-$saved%")
                        }
                        Text(fmtSize(total), color = Primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Label("OUTPUT FILES")
            files.forEach { f ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, color = OnSurf, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(fmtSize(f.length()), color = OnSurfVar, fontSize = 13.sp)
                    }
                    IconButton(onClick = { a.playFile(f) }) { Icon(Icons.Default.PlayArrow, "Play", tint = Primary) }
                }
            }

            Panel {
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.Info, null, tint = Primary)
                    Text(
                        "To post as a Status: save to gallery, then open WhatsApp > Status and pick the clips.",
                        color = OnSurfVar, fontSize = 14.sp
                    )
                }
            }

            BigButton("Send via WhatsApp", { a.share(files, true) })
            BigButton("Share", { a.share(files, false) }, primary = false)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { a.save(files) },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(50)
                ) { Text("Save to Gallery", color = OnSurf) }
                OutlinedButton(
                    onClick = onAnother,
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(50)
                ) { Text("Compress Another", color = OnSurf) }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
