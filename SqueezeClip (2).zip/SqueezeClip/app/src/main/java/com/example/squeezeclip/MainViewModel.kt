package com.example.squeezeclip

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

@OptIn(UnstableApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {

    data class Info(
        val uri: Uri,
        val name: String,
        val durationMs: Long,
        val width: Int,
        val height: Int,
        val sizeBytes: Long
    )

    enum class Preset(val label: String, val sub: String, val shortSide: Int, val bitrate: Int) {
        SHARP("Sharp", "720p HD", 720, 4_000_000),
        BALANCED("Balanced", "Recommended", 720, 2_500_000),
        SMALL("Small", "Mini size", 480, 1_200_000)
    }

    var info by mutableStateOf<Info?>(null)
        private set
    var thumb by mutableStateOf<ImageBitmap?>(null)
        private set
    var resultThumb by mutableStateOf<ImageBitmap?>(null)
        private set
    var preset by mutableStateOf(Preset.BALANCED)
    var split by mutableStateOf(true)
    var trimStart by mutableStateOf(0f)
    var trimEnd by mutableStateOf(0f)
    var working by mutableStateOf(false)
        private set
    var done by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var progress by mutableStateOf(0f)
        private set
    var partIndex by mutableStateOf(0)
        private set
    var partCount by mutableStateOf(1)
        private set
    var remainingSec by mutableStateOf<Int?>(null)
        private set
    val results = mutableStateListOf<File>()

    private var transformer: Transformer? = null
    private var startedAt = 0L
    private val handler = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            val t = transformer
            if (!working || t == null) return
            val holder = ProgressHolder()
            if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                val overall = ((partIndex + holder.progress / 100f) / partCount).coerceIn(0f, 1f)
                progress = overall
                val elapsed = (SystemClock.elapsedRealtime() - startedAt) / 1000f
                remainingSec = if (overall > 0.03f) (elapsed * (1f - overall) / overall).toInt() else null
            }
            handler.postDelayed(this, 300)
        }
    }

    fun applyQuick(p: Preset, splitIntoParts: Boolean) {
        preset = p
        split = splitIntoParts
    }

    fun load(uri: Uri) {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur <= 0 || w <= 0 || h <= 0) {
                status = "That file doesn't look like a playable video."
                return
            }
            val (name, size) = queryMeta(uri)
            info = Info(uri, name, dur, w, h, size)
            thumb = try {
                r.getFrameAtTime(dur * 500, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.asImageBitmap()
            } catch (e: Exception) { null }
            trimStart = 0f
            trimEnd = dur.toFloat()
            results.clear()
            resultThumb = null
            done = false
            status = ""
        } catch (e: Exception) {
            status = "Couldn't read that video."
        } finally {
            r.release()
        }
    }

    fun closeVideo() {
        info = null
        thumb = null
        resultThumb = null
        results.clear()
        done = false
        status = ""
    }

    fun backToEdit() {
        done = false
    }

    private fun queryMeta(uri: Uri): Pair<String, Long> {
        var name = "video"
        var size = 0L
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0) ?: "video"
                        size = c.getLong(1)
                    }
                }
        } catch (e: Exception) { /* keep defaults */ }
        return name to size
    }

    /** The clip ranges (ms) that will be exported with the current settings. */
    fun previewRanges(): List<LongRange> {
        val s = trimStart.toLong()
        val e = trimEnd.toLong()
        if (e - s < 500) return emptyList()
        if (!split || e - s <= PART_MS + 1500) return listOf(s..e)
        val out = mutableListOf<LongRange>()
        var cur = s
        while (cur < e) {
            val next = minOf(cur + PART_MS, e)
            out.add(cur..next)
            cur = next
        }
        if (out.size > 1 && out.last().last - out.last().first < 1500) {
            val tail = out.removeAt(out.lastIndex)
            val prev = out.removeAt(out.lastIndex)
            out.add(prev.first..tail.last)
        }
        return out
    }

    /** Rough output size estimate from the preset bitrate (video + ~128 kbps audio). */
    fun estimatedBytes(): Long {
        val ms = previewRanges().sumOf { it.last - it.first }
        return (ms / 1000.0 * (preset.bitrate + 128_000) / 8.0).toLong()
    }

    private fun targetSize(i: Info): Pair<Int, Int> {
        val shortSide = minOf(i.width, i.height)
        if (shortSide <= preset.shortSide) return i.width to i.height
        val scale = preset.shortSide.toFloat() / shortSide
        return ((i.width * scale).toInt() / 2 * 2) to ((i.height * scale).toInt() / 2 * 2)
    }

    fun start() {
        val i = info ?: return
        if (working) return
        val ranges = previewRanges()
        if (ranges.isEmpty()) { status = "Pick a longer section to compress."; return }
        val dir = File(getApplication<Application>().cacheDir, "exports")
        dir.deleteRecursively()
        dir.mkdirs()
        results.clear()
        resultThumb = null
        done = false
        status = ""
        progress = 0f
        partIndex = 0
        partCount = ranges.size
        remainingSec = null
        startedAt = SystemClock.elapsedRealtime()
        working = true
        runNext(i, ranges, 0, dir)
        handler.post(poll)
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
        working = false
        done = false
        status = "Cancelled."
    }

    private fun frameOf(file: File): ImageBitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.asImageBitmap()
        } catch (e: Exception) {
            null
        } finally {
            r.release()
        }
    }

    private fun runNext(i: Info, ranges: List<LongRange>, index: Int, dir: File) {
        if (index >= ranges.size) {
            transformer = null
            working = false
            progress = 1f
            status = ""
            resultThumb = results.firstOrNull()?.let { frameOf(it) }
            done = true
            return
        }
        partIndex = index
        val ctx = getApplication<Application>()
        val range = ranges[index]
        val out = File(dir, "SqueezeClip_part_%02d.mp4".format(index + 1))

        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(range.first)
            .setEndPositionMs(range.last)
            .build()
        val mediaItem = MediaItem.Builder().setUri(i.uri).setClippingConfiguration(clip).build()

        // Scale down so the shorter side matches the preset; never upscale.
        val videoEffects = mutableListOf<Effect>()
        val (nw, nh) = targetSize(i)
        if (nw != i.width || nh != i.height) {
            videoEffects.add(Presentation.createForWidthAndHeight(nw, nh, Presentation.LAYOUT_SCALE_TO_FIT))
        }
        val edited = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
            .build()

        val encoder = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(preset.bitrate).build()
            )
            .build()

        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    results.add(out)
                    runNext(i, ranges, index + 1, dir)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    transformer = null
                    working = false
                    done = false
                    status = "Failed: ${exportException.errorCodeName}"
                }
            })
            .build()
        transformer = t
        t.start(edited, out.absolutePath)
    }

    override fun onCleared() {
        handler.removeCallbacks(poll)
        transformer?.cancel()
    }

    companion object {
        const val PART_MS = 30_000L
    }
}
