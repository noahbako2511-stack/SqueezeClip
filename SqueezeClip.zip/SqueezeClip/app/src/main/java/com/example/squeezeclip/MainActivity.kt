package com.example.squeezeclip

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Screen(vm, { files, wa -> share(files, wa) }, { files -> saveToGallery(files) })
                }
            }
        }
    }

    private fun share(files: List<File>, whatsAppOnly: Boolean) {
        val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = "video/mp4"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            if (whatsAppOnly) {
                intent.setPackage("com.whatsapp")
                startActivity(intent)
            } else {
                startActivity(Intent.createChooser(intent, "Share"))
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "That app isn't installed.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveToGallery(files: List<File>) {
        var saved = 0
        for (f in files) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "SqueezeClip_${System.currentTimeMillis()}_${f.name}")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SqueezeClip")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: continue
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            saved++
        }
        Toast.makeText(this, "Saved $saved file(s) to Movies/SqueezeClip", Toast.LENGTH_LONG).show()
    }
}

private fun fmtTime(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
private fun fmtSize(bytes: Long) = if (bytes <= 0) "unknown size" else "%.1f MB".format(bytes / 1048576.0)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Screen(
    vm: MainViewModel,
    onShare: (List<File>, Boolean) -> Unit,
    onSave: (List<File>) -> Unit
) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.load(uri)
    }
    val info = vm.info
    val ranges = vm.previewRanges()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("SqueezeClip", style = MaterialTheme.typography.headlineMedium)
        Text("Shrink and split videos before you post them. Everything runs on your phone.")

        Button(
            onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            enabled = !vm.working
        ) { Text(if (info == null) "Choose a video" else "Choose a different video") }

        if (info != null) {
            Text("${fmtTime(info.durationMs)} long, ${info.width}x${info.height}, ${fmtSize(info.sizeBytes)}")

            Text("Trim: ${fmtTime(vm.trimStart.toLong())} to ${fmtTime(vm.trimEnd.toLong())}", style = MaterialTheme.typography.titleSmall)
            RangeSlider(
                value = vm.trimStart..vm.trimEnd,
                onValueChange = { vm.trimStart = it.start; vm.trimEnd = it.endInclusive },
                valueRange = 0f..info.durationMs.toFloat(),
                enabled = !vm.working
            )

            Text("Quality", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MainViewModel.Preset.values().forEach { p ->
                    FilterChip(
                        selected = vm.preset == p,
                        onClick = { vm.preset = p },
                        label = { Text(p.label) },
                        enabled = !vm.working
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Switch(checked = vm.split, onCheckedChange = { vm.split = it }, enabled = !vm.working)
                Text("Split into 30-second parts")
            }
            if (ranges.isNotEmpty()) {
                Text("This will make ${ranges.size} file(s).", style = MaterialTheme.typography.bodySmall)
            }

            if (vm.working) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                OutlinedButton(onClick = vm::cancel) { Text("Cancel") }
            } else {
                Button(onClick = vm::start, enabled = ranges.isNotEmpty()) { Text("Compress") }
            }
        }

        if (vm.status.isNotEmpty()) Text(vm.status)

        if (!vm.working && vm.results.isNotEmpty()) {
            val files = vm.results.toList()
            files.forEach { f -> Text("${f.name}: ${fmtSize(f.length())}") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onSave(files) }) { Text("Save to gallery") }
                OutlinedButton(onClick = { onShare(files, false) }) { Text("Share") }
            }
            OutlinedButton(onClick = { onShare(files, true) }) { Text("Send via WhatsApp") }
            Text(
                "To post as a Status: save to gallery, then open WhatsApp > Status and pick the clips.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
