package com.example.squeezeclip

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

@OptIn(UnstableApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {

    data class Info(val uri: Uri, val durationMs: Long, val width: Int, val height: Int, val sizeBytes: Long)

    enum class Preset(val label: String, val shortSide: Int, val bitrate: Int) {
        SHARP("Sharp", 720, 4_000_000),
        BALANCED("Balanced", 720, 2_500_000),
        SMALL("Small", 480, 1_200_000)
    }

    var info by mutableStateOf<Info?>(null)
        private set
    var preset by mutableStateOf(Preset.BALANCED)
    var split by mutableStateOf(true)
    var trimStart by mutableStateOf(0f)
    var trimEnd by mutableStateOf(0f)
    var working by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    val results = mutableStateListOf<File>()

    private var transformer: Transformer? = null

    fun load(uri: Uri) {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur <= 0 || w <= 0 || h <= 0) {
                status = "That file doesn't look like a playable video."
                return
            }
            info = Info(uri, dur, w, h, querySize(uri))
            trimStart = 0f
            trimEnd = dur.toFloat()
            results.clear()
            status = ""
        } catch (e: Exception) {
            status = "Couldn't read that video."
        } finally {
            r.release()
        }
    }

    private fun querySize(uri: Uri): Long = try {
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getLong(0) else 0L } ?: 0L
    } catch (e: Exception) { 0L }

    /** The clip ranges (ms) that will be exported with the current settings. */
    fun previewRanges(): List<LongRange> {
        val s = trimStart.toLong()
        val e = trimEnd.toLong()
        if (e - s < 500) return emptyList()
        if (!split || e - s <= PART_MS + 1500) return listOf(s..e)
        val out = mutableListOf<LongRange>()
        var cur = s
        while (cur < e) {
            val next = minOf(cur + PART_MS, e)
            out.add(cur..next)
            cur = next
        }
        if (out.size > 1 && out.last().last - out.last().first < 1500) {
            val tail = out.removeAt(out.lastIndex)
            val prev = out.removeAt(out.lastIndex)
            out.add(prev.first..tail.last)
        }
        return out
    }

    fun start() {
        val i = info ?: return
        if (working) return
        val ranges = previewRanges()
        if (ranges.isEmpty()) { status = "Pick a longer section to compress."; return }
        val dir = File(getApplication<Application>().cacheDir, "exports")
        dir.deleteRecursively()
        dir.mkdirs()
        results.clear()
        working = true
        runNext(i, ranges, 0, dir)
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
        working = false
        status = "Cancelled."
    }

    private fun runNext(i: Info, ranges: List<LongRange>, index: Int, dir: File) {
        if (index >= ranges.size) {
            working = false
            status = "Done. ${results.size} file(s) ready."
            return
        }
        status = "Compressing part ${index + 1} of ${ranges.size}..."
        val ctx = getApplication<Application>()
        val range = ranges[index]
        val out = File(dir, "clip_%02d.mp4".format(index + 1))

        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(range.first)
            .setEndPositionMs(range.last)
            .build()
        val mediaItem = MediaItem.Builder().setUri(i.uri).setClippingConfiguration(clip).build()

        // Scale down so the shorter side matches the preset; never upscale.
        val videoEffects = mutableListOf<Effect>()
        val shortSide = minOf(i.width, i.height)
        if (shortSide > preset.shortSide) {
            val scale = preset.shortSide.toFloat() / shortSide
            val nw = ((i.width * scale).toInt() / 2) * 2
            val nh = ((i.height * scale).toInt() / 2) * 2
            videoEffects.add(Presentation.createForWidthAndHeight(nw, nh, Presentation.LAYOUT_SCALE_TO_FIT))
        }
        val edited = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
            .build()

        val encoder = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(preset.bitrate).build()
            )
            .build()

        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    results.add(out)
                    runNext(i, ranges, index + 1, dir)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    working = false
                    status = "Failed: ${exportException.errorCodeName}"
                }
            })
            .build()
        transformer = t
        t.start(edited, out.absolutePath)
    }

    override fun onCleared() {
        transformer?.cancel()
    }

    companion object {
        const val PART_MS = 30_000L
    }
}
